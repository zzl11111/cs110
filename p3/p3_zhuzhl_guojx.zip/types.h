#ifndef TYPES_H
#define TYPES_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

#define NSPEEDS         9
#define NUM_THREADS     28

typedef struct
{
  int    nx;            /* no. of cells in x-direction */
  int    ny;
   float omega;            /* no. of cells in y-direction */
  int    maxIters;      /* no. of iterations */
  int    type;    
       /* inlet type */
  float  viscosity;     /* kinematic viscosity of fluid */
  float  density;       /* density per cell */
  float  velocity;      /* inlet velocity */
         /* relaxation parameter */
         
} t_param;

/* struct to hold the distribution of different speeds */
typedef struct
{
  float speeds[NSPEEDS];
} t_speed;

#endif